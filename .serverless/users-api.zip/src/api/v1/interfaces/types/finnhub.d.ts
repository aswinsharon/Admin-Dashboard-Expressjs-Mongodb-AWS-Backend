declare module "finnhub";
