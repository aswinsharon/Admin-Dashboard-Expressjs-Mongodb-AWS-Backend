import { Request, Response } from "express";
import bcrypt from "bcryptjs";
import { User } from "../models/userSchema";
// import { Constants } from "../../../config/constants";

const handleLogin = async (req: Request, res: Response) => {
  let loginResponse = {
    statusCode: 0,
    message: "",
    invalidFields: [] as string[],
  };
  const { username, password } = req.body;

  if (!username || !password) {
    loginResponse.statusCode = 400;
    loginResponse.message = "Username or Password Field is empty";
    loginResponse.invalidFields = ["username", "password"];
    return res.status(400).json(loginResponse);
  }

  try {
    const foundUser = await User.findOne({ username: username });
    console.log("foundUser", foundUser);
    if (!foundUser) {
      loginResponse.statusCode = 401;
      loginResponse.message = "User is not registered";
      loginResponse.invalidFields = ["username"];
      return res.status(401).json(loginResponse);
    }
    const match = await bcrypt.compare(password, foundUser.password);
    if (match) {
      loginResponse.statusCode = 204;
      loginResponse.message = "";
      return res.json(loginResponse);
    } else {
      loginResponse.statusCode = 401;
      loginResponse.message = "Wrong password";
      loginResponse.invalidFields = ["password"];
      return res.status(401).json(loginResponse);
    }
  } catch (error) {
    console.error(error);
    loginResponse.statusCode = 500;
    loginResponse.message = "Internal Server Error";
    loginResponse.invalidFields = [];
    return res.status(500).json(loginResponse);
  }
};

export default { handleLogin };
